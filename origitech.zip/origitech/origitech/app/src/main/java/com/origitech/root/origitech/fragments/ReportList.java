package com.origitech.root.origitech.fragments;

import android.support.v4.app.Fragment;

/**
 * Created by root on 10/23/15.
 */
public class ReportList extends Fragment {

}
